package br.gov.sp.fatec.projetolabiv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetolabivApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjetolabivApplication.class, args);
	}

}
