package br.gov.sp.fatec.projetolabiv;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetolabivApplicationTests {

	@Test
	void contextLoads() {
	}

}
